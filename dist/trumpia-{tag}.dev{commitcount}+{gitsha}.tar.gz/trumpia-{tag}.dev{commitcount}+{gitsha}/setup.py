from distutils.core import setup

version_format = '{tag}.dev{commitcount}+{gitsha}'

setup(name='trumpia',
      packages=['trumpia'],
      version=version_format,
      description='Python wrapper for Trumpia API',
      license='MIT',
      author='Alex Luis Arias',
      author_email='alex@alexarias.io',
      url='http://github.com/aleksarias/trumpia-python',
      keywords=['trumpia', 'api', 'python'],
      setup_requires=['setuptools-git-version'],
      classifiers=[],
      zip_safe=False)
