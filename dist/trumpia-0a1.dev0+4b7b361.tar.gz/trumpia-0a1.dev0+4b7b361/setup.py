from setuptools import setup


setup(name='trumpia',
      version_format='{tag}.dev{commitcount}+{gitsha}',
      setup_requires=['setuptools-git-version'],
      description='Python wrapper for Trumpia API',
      url='http://github.com/aleksarias/trumpia-python',
      author='Alex Luis Arias',
      author_email='alex@alexarias.io',
      license='MIT',
      packages=['trumpia'],
      zip_safe=False)
